import React from 'react';
import './Error.css'
const Error =  () => (
    <div className="oaerror danger">
    <strong>Network Error! </strong>- Please try again later.
  </div>
);

export default Error;