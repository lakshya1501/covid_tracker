import React from 'react';

import './Spinner.css';

const spinner = () => (
    <div className="Loader">Loading...</div>
);

export default spinner;